# Program       : gradienmagis.py
# Deskripsi     : Source Code Gradien Magis
# NIM/Nama      : 24060124140149/Devano Trestanto
# Tanggal       : 27/09/2024

def gradien(a,b):
    return ((3*(a**2) + 2*a - 5) - ((3*(b**2)+2*b-5)))/ (a-b)
    
print(eval(input()))